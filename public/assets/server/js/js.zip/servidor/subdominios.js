window.onload = (function(){
try{
    $("#buscarsubdominio").on('keyup', function(){
             
        $('#bodyTable').html('<td colspan="16" align="center"><div style = "color: gray;font-size: 15px;"><img src="../public/assets/server/img/loading.gif" /></div></td>')
        var value = $(this).val();
        if(value == ""){
            allsubdominios("");
           
        }else{

           allsubdominios(value);
        }
    }).keyup();

    
}catch(e){}



});

$("#buttonreload").on('click', function(){
  $('#bodyTable').html('<td colspan="16" align="center"><div style = "color: gray;font-size: 15px;"><img src="../public/assets/server/img/loading.gif" /></div></td>')
   setTimeout(function(){                
                 allsubdominios("");
             }, 1000) 

})




function allsubdominios(buscar){
    var data_form = {
        buscarsubdominio :buscar      
    }

   var url_php = 'subdominios/getAllsubdominios';
   $.ajax({
        type:'POST',
        url: url_php,
        data: data_form,
        dataType: 'json',
        async: true,
        beforeSend: function() {
         //('#reloadIcloud').html('<img src="../assets/img/loading.gif" /><a>Procesando<a>');
        },
    }).done(function ajaxDone(res){
        $('#reloadIcloud').html('');
        $("#bodyTable").html('');
        if(res != null && $.isArray(res)){
            var i = 1;
            if(res == ""){
                $("#bodyTable").html('<td colspan="16" align="center"><div style = "color: gray;font-size: 15px;">No tienes Requerimientos que mostrar</div></td>'); 
               
            }else{
             $.each(res, function(index, value){

              let btn = "";  
              btn = "<td><font class='btn btn-sm' style = 'cursor: pointer;' onclick='eliminarsubdominio("+value.idsubdomains+")'><span class='fa fa-times' aria-hidden='true' style = 'color: #dc3545;font-size: 20px;'></span></font></td>";
              $("#bodyTable").append("<tr>"                                       
                                       + "<td>"+i+"</td>"
                                       + "<td data-label='Descripción'>" + value.subdomains + "</td>"
                                       + btn
                                       + "</div></td></tr>"); 
                
                i++;
             });
            } 
        }   


      
    }).fail(function ajaxError(e){
        console.log(e);
    }).always(function ajaxSiempre(){
       // console.log('Final de la llamada ajax.');
    })
    return false;  


}


function reloadsubdom(){

  $("#selecsubdom").html("");
  $("#selecsubdomaco").html("");
 
  
    
    var url_php = 'subdominios/getAllsubdominios';
    $.ajax({
        type:'POST',
        url: url_php,
        data: '',
        dataType: 'json',
        async: true,
        beforeSend: function() {
         
        },
    }).done(function ajaxDone(res){

      if(res != null && $.isArray(res)){
        
          $.each(res, function(index, value){


            $("#selecsubdom").append("<option value = "+value.idsubdomains+">"+value.subdomains + "</option>");
            $("#selecsubdomaco").append("<option value = "+value.idsubdomains+">"+value.subdomains +"</option>");
           


                  
          })

       }



    }).fail(function ajaxError(e){
        console.log(e);
    }).always(function ajaxSiempre(){
       // console.log('Final de la llamada ajax.');*/
    })
    return false; 


}


$(document).on("submit", ".form-addsubdominio", function(event){
    event.preventDefault();

    $('#loaderadd').html('<center><div style = "color: gray;font-size: 15px;"><img src="../public/assets/server/img/loading.gif" /></div></center>')
    $("#subdominio").removeClass('is-invalid');
    const Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 3000
      });
       var data_form = {
          domtemp : $("#domtemp").val(),
          descripcion : $("#subdominio").val(),
          rutaSubd : $("#rutaSubd").val()
          //selecttipo :$("#selecttipo").val()     
      }

      var url_php = 'subdominios/agregarsubdominio';
      $.ajax({
        type:'POST',
        url: url_php,
        data: data_form,
        dataType: 'json',
        async: true,
    }).done(function ajaxDone(res){

        if(res.statusAdd !== undefined){        
            if(res.statusAdd == true){
    
                 Toast.fire({
                  type: 'success',
                  title: '&nbsp; Datos ingresados correctamente'
                })   
                allsubdominios("");
                reloadsubdom()
                 $("#subdominio").removeClass('is-invalid'); 
                 $('#loaderadd').html('')
    
             }else if(res.statusAdd == false){
             if(res.addsubdominio == false){
    
              Toast.fire({
                       type: 'error',
                       title: '&nbsp; Error al ingresar los datos.<br>Sub Dominio ya registrado o invalido'
                     }) 
               $('#loaderadd').html('')
    
             }else if(res.formError == true){
    
               if($("#dominio").val() == ""){
    
                      console.log(res.formError + " - " + res.statusAdd)
    
    
                      Toast.fire({
                         type: 'error',
                         title: '&nbsp; Error al ingresar los datos.'
                         }) 
    
                 
                       $("#subdominio").addClass('is-invalid'); 
                    }else{
                       $("#subdominio").removeClass('is-invalid'); 
                    } 
    
                     $('#loaderadd').html('')
    
             }
          }  
          }
    
   
    }).fail(function ajaxError(e){
       console.log(e);
   }).always(function ajaxSiempre(){
      // console.log('Final de la llamada ajax.');
   })
   return false;  
})


$(document).on("submit", ".form-adddominio", function(event){
    event.preventDefault();

    $('#loaderadd2').html('<center><div style = "color: gray;font-size: 15px;"><img src="../public/assets/server/img/loading.gif" /></div></center>')
    $("#subdominio").removeClass('is-invalid');
    const Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 5000
      });
       var data_form = {
          dominio : $("#dominio").val(),
          rutaD : $("#rutaD").val()
          //selecttipo2 : $("#selecttipo2").val() 
      }



      var url_php = 'subdominios/agregardominio';
      $.ajax({
        type:'POST',
        url: url_php,
        data: data_form,
        dataType: 'json',
        async: true,
    }).done(function ajaxDone(res){

        if(res.statusAdd !== undefined){        
            if(res.statusAdd == true){
    
                 Toast.fire({
                  type: 'success',
                  title: '&nbsp; Dominios agregado correctamente'
                })   
                allsubdominios("");
                reloadsubdom()
                 $("#subdominio").removeClass('is-invalid'); 
                 $('#loaderadd2').html('')

                 console.log(res)
    
             }else if(res.statusAdd == false){

              Toast.fire({
                       type: 'error',
                       title: '&nbsp; Hubo un error.<br>Dominio ya registrado o invalido'
                     }) 
               $('#loaderadd2').html('')

            }  
          }
    
   
    }).fail(function ajaxError(e){
       console.log(e);
   }).always(function ajaxSiempre(){
      // console.log('Final de la llamada ajax.');
   })
   return false;  
})






function eliminarsubdominio(idsubdomains){
    
    const Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 3000
      });

    $('#bodyTable').html('<td colspan="16" align="center"><div style = "color: gray;font-size: 15px;"><img src="../public/assets/server/img/loading.gif" /></div></td>')
       var data_form = {
        idsubdomains  : idsubdomains  
      }

   
      
      var url_php = 'subdominios/eliminarsubdominio';
      $.ajax({
          type:'POST',
          url: url_php,
          data: data_form,
          dataType: 'json',
          async: true,
      }).done(function ajaxDone(res){   
        
         
  
         if(res.statusdelete == true){
              $('#bodyTable').html('<td colspan="4" align="center"><div style = "color: gray;font-size: 15px;"><img src="../public/assets/server/img/loading.gif" /></div></td>')
             
              Toast.fire({
                type: 'success',
                title: '&nbsp; Subdominio eliminado exitosamente.<br>'
              }) 

              allsubdominios(""); 
              reloadsubdom()
             
          }else if(res.statusdelete == false){
              
  
            Toast.fire({
                type: 'error',
                title: '&nbsp; Error al eliminar el Subdominio.<br>'
              }) 

              allsubdominios("");  

          }
  
        
  
  
        
      }).fail(function ajaxError(e){
          console.log(e);
      }).always(function ajaxSiempre(){
         // console.log('Final de la llamada ajax.');
      })
      return false;  
  
      
  }



 



 

  
 